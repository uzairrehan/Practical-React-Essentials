import { Contact } from '../entities/contact.entity';
export class CreateContactDto extends Contact {}
