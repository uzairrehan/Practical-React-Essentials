const Info = () => {
  return (
    <div className="text-center">
      <h2 className="text-lg">This is the info page in about</h2>
    </div>
  )
}

export default Info